//
//  FirstViewController.h
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>
#import <Firebase/Firebase.h>

@interface FirstViewController : UIViewController

- (IBAction) reportIncident:(id)sender;
- (IBAction) incidentInfo:(id)sender;



@end
